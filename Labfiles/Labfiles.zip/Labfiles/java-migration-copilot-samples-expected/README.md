# Java Migration Copilot Samples

Some sample projects that can be fed to the Java migration tool to replatform them to Azure.

## Branches

* `main`: source projects
* `expected`: expected changes after migration
